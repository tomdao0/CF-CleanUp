- Bài tập không tính điểm, nhưng mình recommend bạn cố gắng hoàn thành để thực tập kỹ năng data

- Có khó khăn gì trong quá trình làm bài, bạn nhắn mình trên group


# HƯỚNG DẪN

- Bạn vui lòng cài đặt Anaconda và có Jupter Notebook/Lab trước

- Để file Notebook chạy chính xác và load ảnh được, bạn hãy trỏ tới thư mục HW1 này (có file HUONGDAN.md)

- Tại đây bạn mở jupyter notebook hoặc jupter lab (gõ jupyter notebook trong command line)

## Structure

- static: chứa ảnh cho notebook

- data: chứa csv files cho bài tập

## SQL

- Hiện giờ bài tập SQL đang maintainance chưa thể public được